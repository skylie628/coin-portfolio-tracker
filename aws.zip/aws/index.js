const axios = require("axios");
const redis = require("redis");
const client = redis.createClient({
  url: "redis://default:IYvXmQk8GYlLhFkeb98KtZFr7zEyMCGv@redis-13120.c267.us-east-1-4.ec2.cloud.redislabs.com:13120",
});

//const setAsync = promisify(client.set).bind(client);

exports.handler = async (event) => {
  try {
    // Start the client
    client.connect();
    const cachedValue = await client.get("topMarketCap");
    console.log("cachedValue", cachedValue);
    const topSearchTrending = await axios
      .get("https://api.coingecko.com/api/v3/search/trending")
      .then((res) => ({
        coins: res.data.coins.slice(0, 10),
        categories: res.data.categories.slice(0, 4),
      }));
    const topMarketCap = await axios
      .get("https://api.coingecko.com/api/v3/coins/markets", {
        params: {
          vs_currency: "usd",
          order: "market_cap_desc",
          per_page: 10,
          page: 1,
          sparkline: true,
        },
      })
      .then((res) => res.data);
    // Cache the data in Redis for 10 minutes
    await client.set(
      "topSearchTrending",
      JSON.stringify(topSearchTrending),
      "EX",
      600
    );
    await client.set("topMarketCap", JSON.stringify(topMarketCap), "EX", 600);
  } catch (error) {
    console.error(error);
  } finally {
    // Close the client
    client.quit();
  }
};
exports.handler();
